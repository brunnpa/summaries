package ch.zhaw.ads;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class BracketServer {

    private HashSet openingBrackets;
    private HashSet closingBrackets;
    private HashSet mathOperators;
    private HashMap<Character, Character> bracketTable;


    public BracketServer() {
        openingBrackets = new HashSet();
        closingBrackets = new HashSet();
        mathOperators = new HashSet();
        openingBrackets.add('[');
        openingBrackets.add('(');
        openingBrackets.add('{');
        closingBrackets.add(']');
        closingBrackets.add('}');
        closingBrackets.add(')');
        mathOperators.add('+');
        mathOperators.add('-');
        mathOperators.add('*');
        mathOperators.add(' ');
        mathOperators.add('/');
        bracketTable = new HashMap<>();
        bracketTable.put('{', '}');
        bracketTable.put('[', ']');
        bracketTable.put('(', ')');
    }

    public boolean checkBrackets(String input) {
        ListStack<Character> bracketStack = new ListStack<>();

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            // Check if input is a closing bracket and has no corresponding opening bracket on top of the stack.
            if (closingBrackets.contains(c) && bracketTable.get(bracketStack.peek()) != c) {
                return false;
            }

            // Check if input is a closing bracket and has a corresponding opening bracket on top of the stack.
            else if (closingBrackets.contains(c) && bracketTable.get(bracketStack.peek()) == c) {
                bracketStack.pop();
            }

            // Check if c is a opening bracket. If yes, push it onto the stack.
            else if (openingBrackets.contains(c)) {
                bracketStack.push(c);
                // return true;
            }
        }
        return bracketStack.isEmpty();
    }
}


