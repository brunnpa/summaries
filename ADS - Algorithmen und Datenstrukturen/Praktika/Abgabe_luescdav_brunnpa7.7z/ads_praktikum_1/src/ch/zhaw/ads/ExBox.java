/**
 * @author K. Rege
 * @version 1.0 -- Experimentierkasten
 */
package ch.zhaw.ads;

import java.io.*;
import java.util.*;


public class ExBox {

    public static void main(String[] args) throws Exception {
        ExBoxFrame f = new ExBoxFrame();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }
}
