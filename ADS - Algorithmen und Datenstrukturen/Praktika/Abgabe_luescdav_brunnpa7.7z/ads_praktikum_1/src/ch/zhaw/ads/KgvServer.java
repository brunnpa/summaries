package ch.zhaw.ads;

import java.io.ByteArrayInputStream;
import java.util.Scanner;

public class KgvServer implements CommandExecutor{


    private int a;
    private int b;

    public KgvServer() {
        a = 0;
        b = 0;
    }

    public int kgv(int a, int b) {
        int kgv;
        int produktDesInputs = (a * b);

        kgv = produktDesInputs / ggT(a, b);
        return kgv;
    }

    private int ggT(int a, int b) {
        if (a > b) {
            return ggT((a - b), b);
        } else if (a < b) {
            return ggT(a, (b - a));
        } else return a;
    }

    public String execute(String s) {
        Scanner scanner = new Scanner(new ByteArrayInputStream(s.getBytes()));
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        return Integer.toString(kgv(a, b));
    }
}
