package ch.zhaw.ads;

import java.util.LinkedList;

public class ListStack<O> implements Stack<O> {

    // Statt LinkedList ArrayList verwenden oder Array?!
    private LinkedList<Object> stack;
    private int top;
    private int bottom;

    public ListStack(){
        stack = new LinkedList<>();
    }

    public void push(O element) {
        if (isEmpty()) {
            stack.add(element);
            top = 0;
        }
        else {
            stack.add(element);
            top++;
        }
    }

    public O pop() {
        if (isEmpty()) {
            return null;
        }
        else {
            O element = (O) stack.remove(top);
            if (top > 0) {
                top--;
                return element;
            }
            else {
                return element;
            }
        }
    }

    public O peek() {
        return (O) stack.peekLast();
    }

    public boolean isEmpty() {
        if (stack.size() == 0) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean isFull() {
        return false;
    }
}
