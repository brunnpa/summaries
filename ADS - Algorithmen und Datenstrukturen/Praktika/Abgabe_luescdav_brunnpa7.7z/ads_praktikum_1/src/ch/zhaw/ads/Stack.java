package ch.zhaw.ads;

public interface Stack<O> {

    void push(O element);

    O pop();

    O peek();

    boolean isEmpty();

    boolean isFull();
}
