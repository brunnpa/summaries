package ch.zhaw.ads;

public class XmlFileTester {


    // Check if XML is well formed
    public boolean checkWellformed(String arg) {

    }

    // Returns the next token.
    private String getNextToken() {

    }
}
