package praktikum_10;

public enum SortMethod {
    BUBBLE_SORT, SELECTION_SORT, INSERTION_SORT
}

