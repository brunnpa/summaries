package invalidPackageName;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import invalidPackageName.Address;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PaymentDetails
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-11-19T10:10:08.925Z[GMT]")


public class PaymentDetails   {
  @JsonProperty("address")
  private Address address = null;

  /**
   * Gets or Sets methodOfPayment
   */
  public enum MethodOfPaymentEnum {
    CREDIT_CARD("CREDIT_CARD"),
    
    BITCOIN("BITCOIN");

    private String value;

    MethodOfPaymentEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static MethodOfPaymentEnum fromValue(String text) {
      for (MethodOfPaymentEnum b : MethodOfPaymentEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("methodOfPayment")
  private MethodOfPaymentEnum methodOfPayment = null;

  public PaymentDetails address(Address address) {
    this.address = address;
    return this;
  }

  /**
   * Get address
   * @return address
   **/
  @Schema(required = true, description = "")
      @NotNull

    @Valid
    public Address getAddress() {
    return address;
  }

  public void setAddress(Address address) {
    this.address = address;
  }

  public PaymentDetails methodOfPayment(MethodOfPaymentEnum methodOfPayment) {
    this.methodOfPayment = methodOfPayment;
    return this;
  }

  /**
   * Get methodOfPayment
   * @return methodOfPayment
   **/
  @Schema(example = "CREDIT_CARD", description = "")
  
    public MethodOfPaymentEnum getMethodOfPayment() {
    return methodOfPayment;
  }

  public void setMethodOfPayment(MethodOfPaymentEnum methodOfPayment) {
    this.methodOfPayment = methodOfPayment;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PaymentDetails paymentDetails = (PaymentDetails) o;
    return Objects.equals(this.address, paymentDetails.address) &&
        Objects.equals(this.methodOfPayment, paymentDetails.methodOfPayment);
  }

  @Override
  public int hashCode() {
    return Objects.hash(address, methodOfPayment);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PaymentDetails {\n");
    
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    methodOfPayment: ").append(toIndentedString(methodOfPayment)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
