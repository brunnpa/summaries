package io.swagger.api;

import invalidPackageName.Bid;
import invalidPackageName.PaymentDetails;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-11-19T10:10:08.925Z[GMT]")
@RestController
public class PaymentdetailsApiController implements PaymentdetailsApi {

    private static final Logger log = LoggerFactory.getLogger(PaymentdetailsApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public PaymentdetailsApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<PaymentDetails> getPaymentDetails() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<PaymentDetails>(objectMapper.readValue("{\n  \"address\" : {\n    \"zipCode\" : 8001,\n    \"streetNumber\" : \"5c\",\n    \"city\" : \"Zürich\",\n    \"street\" : \"Bahnhofstrasse\"\n  },\n  \"methodOfPayment\" : \"CREDIT_CARD\"\n}", PaymentDetails.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<PaymentDetails>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<PaymentDetails>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<Bid>> updatePaymentDetails(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody Bid body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<Bid>>(objectMapper.readValue("[ {\n  \"bidder\" : {\n    \"firstname\" : \"Max\",\n    \"birthdate\" : \"1991-08-01T00:00:00.000Z\",\n    \"address\" : {\n      \"zipCode\" : 8001,\n      \"streetNumber\" : \"5c\",\n      \"city\" : \"Zürich\",\n      \"street\" : \"Bahnhofstrasse\"\n    },\n    \"id\" : \"4bc5cba8-1be0-40b2-a005-9fa81d6842cf\",\n    \"lastname\" : \"Mustermann\"\n  },\n  \"id\" : \"24b9c75b-dc89-491f-bda9-e29e32a359f1\"\n}, {\n  \"bidder\" : {\n    \"firstname\" : \"Max\",\n    \"birthdate\" : \"1991-08-01T00:00:00.000Z\",\n    \"address\" : {\n      \"zipCode\" : 8001,\n      \"streetNumber\" : \"5c\",\n      \"city\" : \"Zürich\",\n      \"street\" : \"Bahnhofstrasse\"\n    },\n    \"id\" : \"4bc5cba8-1be0-40b2-a005-9fa81d6842cf\",\n    \"lastname\" : \"Mustermann\"\n  },\n  \"id\" : \"24b9c75b-dc89-491f-bda9-e29e32a359f1\"\n} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<Bid>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<Bid>>(HttpStatus.NOT_IMPLEMENTED);
    }

}
