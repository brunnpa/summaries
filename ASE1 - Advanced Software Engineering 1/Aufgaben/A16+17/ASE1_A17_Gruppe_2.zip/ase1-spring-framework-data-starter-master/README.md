# Testproject for Spring Framework (without Spring Boot)

You can clone and use the maven wrapper. From MacOS and Linux use ./mvnw ... from Windows mvnw.

## MacOs

./mvnw clean test


## Windows

mvnw clean test


## Start the Application

Use the IDE to run MainJPASpringData, You can configure the application in the file main/resources/spring-data-config-hi.xml.





