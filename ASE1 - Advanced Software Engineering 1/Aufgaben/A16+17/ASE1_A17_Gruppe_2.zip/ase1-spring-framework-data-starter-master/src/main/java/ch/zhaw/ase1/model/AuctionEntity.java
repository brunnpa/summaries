package ch.zhaw.ase1.model;

import com.sun.istack.NotNull;
import org.eclipse.persistence.jpa.jpql.parser.DateTime;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.beans.factory.annotation.Value;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
public class AuctionEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @NotNull
    private int Id;

    @Temporal(TemporalType.DATE)
    @NotNull
    private Date endDateTime;

    @NotNull
    private boolean fixedPrice;
    private int miniBidIncrement;

    @Basic
    @Temporal(TemporalType.DATE)
    @NotNull
    private Date startDateTime;


    @NotNull
    private int startingPrice;

    @NotNull
    private String status;

    @ManyToOne
    @NotNull
    private CategoryEntity category;

    @OneToOne(mappedBy = "auction")
    @NotNull
    private AuctionItemEntity auctionItem;

    @OneToMany(mappedBy = "auction")
    @LazyCollection(LazyCollectionOption.FALSE)
    @NotNull
    private List<BidEntity> bids = new ArrayList<>();

    public AuctionEntity(Date startDateTime, Date endDateTime, boolean fixedPrice, int startingPrice, int miniBidIncrement, String status, CategoryEntity category, AuctionItemEntity auctionItem) {
        this.endDateTime = endDateTime;
        this.fixedPrice = fixedPrice;
        this.miniBidIncrement = miniBidIncrement;
        this.startDateTime = startDateTime;
        this.startingPrice = startingPrice;
        this.status = status;
        this.category = category;
        this.auctionItem = auctionItem;

        auctionItem.setAuction(this);
        category.getAuctions().add(this);
    }

    public AuctionEntity() {

    }

    public Date getEndDateTime() {
        return endDateTime;
    }

    public boolean isFixedPrice() {
        return fixedPrice;
    }

    public int getMiniBidIncrement() {
        return miniBidIncrement;
    }

    public Date getStartDateTime() {
        return startDateTime;
    }

    public int getStartingPrice() {
        return startingPrice;
    }

    public String getStatus() {
        return status;
    }

    public CategoryEntity getCategory() {
        return category;
    }

    public AuctionItemEntity getAuctionItem() {
        return auctionItem;
    }

    public List<BidEntity> getBids() {
        return bids;
    }

    public void setAuctionItem(AuctionItemEntity auctionItem) {
        this.auctionItem = auctionItem;
    }

    public void setCategory(CategoryEntity category) {
        this.category = category;
    }

    public int getId() {
        return Id;
    }
}
