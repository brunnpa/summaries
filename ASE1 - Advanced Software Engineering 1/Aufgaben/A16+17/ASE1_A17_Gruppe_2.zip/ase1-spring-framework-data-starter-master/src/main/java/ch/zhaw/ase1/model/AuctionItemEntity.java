package ch.zhaw.ase1.model;

import javax.persistence.*;

@Entity
public class AuctionItemEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private int Id;

    private String title;
    private String description;
    @Column(length = 4096)
    private String pictureBase64;

    @ManyToOne
    private AuctionEntity auction;

    public AuctionItemEntity(String title, String description, String pictureBase64, AuctionEntity auction) {
        this.title = title;
        this.description = description;
        this.pictureBase64 = pictureBase64;
        setAuction(auction);
    }

    public AuctionItemEntity(){

    }

    public int getId() {
        return Id;
    }

    public AuctionEntity getAuction() {
        return auction;
    }

    public void setAuction(AuctionEntity auction) {
        this.auction = auction;
    }
}
