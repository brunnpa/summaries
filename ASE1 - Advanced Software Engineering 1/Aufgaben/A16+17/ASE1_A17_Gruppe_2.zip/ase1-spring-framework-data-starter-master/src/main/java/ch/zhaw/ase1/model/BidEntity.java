package ch.zhaw.ase1.model;

import org.eclipse.persistence.jpa.jpql.parser.DateTime;
import org.springframework.dao.DataIntegrityViolationException;

import javax.persistence.*;
import java.util.Date;


@Entity
public class BidEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private int Id;

    private int amount;
    private String cancelExplanation;

    @Basic
    @Temporal(TemporalType.DATE)
    private Date placedAtDateTime;

    @ManyToOne
    private AuctionEntity auction;

    public BidEntity(int amount, String cancelExplanation, Date placedAtDateTime) {
        this.amount = amount;
        this.cancelExplanation = cancelExplanation;
        this.placedAtDateTime = placedAtDateTime;
    }

    public BidEntity() {
    }

    public int getId(){
        return Id;
    }

    public String getCancelExplanation() {
        return cancelExplanation;
    }

    public Date getPlacedAtDateTime() {
        return placedAtDateTime;
    }

    public AuctionEntity getAuction() {
        return auction;
    }

    public int getAmount(){
        return amount;
    }
}
