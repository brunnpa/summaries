package ch.zhaw.ase1.model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class CategoryEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private int Id;

    private String description;
    private String name;

    @OneToMany
    private List<AuctionEntity> auctions = new ArrayList<>();

    public CategoryEntity(String name, String description) {
        this.description = description;
        this.name = name;
    }

    public CategoryEntity() {
    }

    public int getId() {
        return Id;
    }

    public List<AuctionEntity> getAuctions() {
        return auctions;
    }
}
