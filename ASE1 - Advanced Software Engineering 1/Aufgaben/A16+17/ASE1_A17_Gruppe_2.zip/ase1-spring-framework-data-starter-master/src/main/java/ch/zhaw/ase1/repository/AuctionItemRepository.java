package ch.zhaw.ase1.repository;

import ch.zhaw.ase1.model.AuctionItemEntity;
import org.springframework.data.repository.CrudRepository;

public interface AuctionItemRepository extends CrudRepository<AuctionItemEntity, Integer> {
}
