package ch.zhaw.ase1.repository;

import ch.zhaw.ase1.model.AuctionEntity;
import org.springframework.data.repository.CrudRepository;

public interface AuctionRepository extends CrudRepository<AuctionEntity, Integer> {
}
