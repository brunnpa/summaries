package ch.zhaw.ase1.repository;

import ch.zhaw.ase1.model.AuctionItemEntity;
import ch.zhaw.ase1.model.CategoryEntity;
import org.springframework.data.repository.CrudRepository;

public interface CategoryRepository  extends CrudRepository<CategoryEntity, Integer> {
}
