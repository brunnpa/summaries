package ch.zhaw.ase1.service;

import ch.zhaw.ase1.model.AuctionItemEntity;
import ch.zhaw.ase1.model.PersonEntity;
import ch.zhaw.ase1.repository.AuctionItemRepository;
import ch.zhaw.ase1.repository.AuctionRepository;
import ch.zhaw.ase1.repository.BidRepository;
import ch.zhaw.ase1.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(propagation = Propagation.NESTED)
public class AuctionItemService {
    @Autowired
    private AuctionItemRepository auctionItemRepository;

    public AuctionItemEntity save(final AuctionItemEntity entity) {
        return auctionItemRepository.save(entity);
    }

    public AuctionItemEntity findOne(final Integer id) {
        return auctionItemRepository.findById(id).orElse(null);
    }

    public AuctionItemEntity findOne(final Long id) {
        return auctionItemRepository.findById((int)(long)id).orElse(null);
    }

    public Iterable<AuctionItemEntity> findAll() {
        return auctionItemRepository.findAll();
    }
}
