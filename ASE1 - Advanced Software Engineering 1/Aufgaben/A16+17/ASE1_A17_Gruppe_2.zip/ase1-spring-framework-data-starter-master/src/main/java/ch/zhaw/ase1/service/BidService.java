package ch.zhaw.ase1.service;

import ch.zhaw.ase1.model.BidEntity;
import ch.zhaw.ase1.repository.AuctionItemRepository;
import ch.zhaw.ase1.repository.AuctionRepository;
import ch.zhaw.ase1.repository.BidRepository;
import ch.zhaw.ase1.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(propagation = Propagation.NESTED)
public class BidService {

    @Autowired
    private BidRepository repository;

    public BidEntity save(final BidEntity entity) {
        if(entity.getAmount() < 0){
            throw new DataIntegrityViolationException("Amount should");
        }
        return repository.save(entity);
    }

    public BidEntity findOne(final Integer id) {
        return repository.findById(id).orElse(null);
    }

    public BidEntity findOne(final Long id) {
        return repository.findById((int)(long)id).orElse(null);
    }

    public Iterable<BidEntity> findAll() {
        return repository.findAll();
    }
}
