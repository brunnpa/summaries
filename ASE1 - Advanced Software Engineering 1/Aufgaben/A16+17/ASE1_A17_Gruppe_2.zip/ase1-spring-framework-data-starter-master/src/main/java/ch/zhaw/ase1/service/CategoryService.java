package ch.zhaw.ase1.service;

import ch.zhaw.ase1.model.CategoryEntity;
import ch.zhaw.ase1.repository.AuctionItemRepository;
import ch.zhaw.ase1.repository.AuctionRepository;
import ch.zhaw.ase1.repository.BidRepository;
import ch.zhaw.ase1.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(propagation = Propagation.NESTED)
public class CategoryService {

    @Autowired
    private CategoryRepository repository;

    public CategoryEntity save(final CategoryEntity entity) {
        return repository.save(entity);
    }

    public CategoryEntity findOne(final Integer id) {
        return repository.findById(id).orElse(null);
    }

    public CategoryEntity findOne(final Long id) {
        return repository.findById((int)(long)id).orElse(null);
    }

    public Iterable<CategoryEntity> findAll() {
        return repository.findAll();
    }
}
