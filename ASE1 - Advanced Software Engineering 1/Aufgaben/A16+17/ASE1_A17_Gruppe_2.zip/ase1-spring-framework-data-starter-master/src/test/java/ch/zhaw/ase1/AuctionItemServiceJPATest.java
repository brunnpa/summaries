package ch.zhaw.ase1;

import ch.zhaw.ase1.config.PersistenceJPAConfigXml;
import ch.zhaw.ase1.model.Address;
import ch.zhaw.ase1.model.AuctionItemEntity;
import ch.zhaw.ase1.model.PersonEntity;
import ch.zhaw.ase1.service.AuctionItemService;
import ch.zhaw.ase1.service.PersonService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import java.util.Iterator;
import java.util.List;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("/jpa-config-hi.xml")
@ContextConfiguration(classes = { PersistenceJPAConfigXml.class }, loader = AnnotationConfigContextLoader.class)
public class AuctionItemServiceJPATest {

    @Autowired
    private AuctionItemService service;

    @Test
    public final void whenContextIsBootstrapped_thenNoExceptions() {
        //
    }

    @Test
    public final void whenEntityIsCreated_thenNoExceptions() {
        service.save(new AuctionItemEntity(randomAlphabetic(6),randomAlphabetic(128), randomAlphabetic(256), null));
    }

    @Test(expected = DataIntegrityViolationException.class)
    public final void whenInvalidEntityIsCreated_thenDataException() {
        service.save(new AuctionItemEntity(randomAlphabetic(6),randomAlphabetic(128), randomAlphabetic(4100), null));
    }

    @Test
    public final void whenEntityIsCreated_thenFound() {
        final AuctionItemEntity entity = new AuctionItemEntity(randomAlphabetic(6),randomAlphabetic(128), randomAlphabetic(256), null);
        service.save(entity);
        final AuctionItemEntity found = service.findOne(entity.getId());
        Assert.assertNotNull(found);
    }

    @Test
    public final void test_findAllEntities(){
        for (int i = 0; i < 10; i++){
            AuctionItemEntity entity = new AuctionItemEntity(randomAlphabetic(6),randomAlphabetic(128), randomAlphabetic(256), null);
            service.save(entity);
        }

        Iterable<AuctionItemEntity> entities = service.findAll();

        int i = 0;
        for (AuctionItemEntity e : entities){
            i++;
        }

        Assert.assertEquals(10, i);
    }


}
