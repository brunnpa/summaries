package ch.zhaw.ase1;

import ch.zhaw.ase1.config.PersistenceJPAConfigXml;
import ch.zhaw.ase1.model.AuctionEntity;
import ch.zhaw.ase1.model.AuctionItemEntity;
import ch.zhaw.ase1.model.CategoryEntity;
import ch.zhaw.ase1.service.AuctionItemService;
import ch.zhaw.ase1.service.AuctionService;
import ch.zhaw.ase1.service.CategoryService;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import java.time.Instant;
import java.time.temporal.TemporalAmount;
import java.time.temporal.TemporalUnit;
import java.util.Date;

import static org.apache.commons.lang3.RandomStringUtils.random;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("/jpa-config-hi.xml")
@ContextConfiguration(classes = { PersistenceJPAConfigXml.class }, loader = AnnotationConfigContextLoader.class)
public class AuctionServiceJPATest {

    @Autowired
    private AuctionService service;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private AuctionItemService auctionItemService;

    private CategoryEntity category;
    private AuctionItemEntity auctionItem;

    @Before
    public final void SetUp(){
        category = new CategoryEntity(randomAlphabetic(19), randomAlphabetic(50));
        categoryService.save(category);

        auctionItem = new AuctionItemEntity(randomAlphabetic(6),randomAlphabetic(128), randomAlphabetic(120), null);
        auctionItemService.save(auctionItem);
    }

    @Test
    public final void whenContextIsBootstrapped_thenNoExceptions() {
        //
    }

    @Test
    public final void whenEntityIsCreated_thenNoExceptions() {
        service.save(new AuctionEntity(Date.from(Instant.now()), Date.from(Instant.now()), false, 10000, 100, randomAlphabetic(5), category, auctionItem));
    }

    @Test(expected = DataIntegrityViolationException.class)
    public final void whenInvalidEntityIsCreated_thenDataException() {
        service.save(new AuctionEntity(Date.from(Instant.now()), Date.from(Instant.now()), false, 10000, 100, randomAlphabetic(512), category, auctionItem ));
    }

    @Test
    public final void whenEntityIsCreated_thenFound() {
        final AuctionEntity entity = new AuctionEntity(Date.from(Instant.now()), Date.from(Instant.now()), false, 10000, 100, randomAlphabetic(5), category, auctionItem);
        service.save(entity);
        final AuctionEntity found = service.findOne(entity.getId());
        Assert.assertNotNull(found);

        Assert.assertEquals(entity, auctionItem.getAuction());
        Assert.assertEquals(auctionItem, entity.getAuctionItem());

        Assert.assertTrue(category.getAuctions().contains(entity));
        Assert.assertEquals(category, entity.getCategory());
    }

    @Test
    public final void test_findAllEntities(){
        for (int i = 0; i < 15; i++){
            AuctionEntity entity = new AuctionEntity(Date.from(Instant.now()), Date.from(Instant.now()), false, 10000, 0, randomAlphabetic(5), category, auctionItem);
            service.save(entity);
        }

        Iterable<AuctionEntity> entities = service.findAll();

        int i = 0;
        for (AuctionEntity e : entities){
            i++;
        }

        Assert.assertEquals(15, i);
    }
}
