package ch.zhaw.ase1;

import ch.zhaw.ase1.config.PersistenceJPAConfigXml;
import ch.zhaw.ase1.model.Address;
import ch.zhaw.ase1.model.BidEntity;
import ch.zhaw.ase1.model.PersonEntity;
import ch.zhaw.ase1.service.BidService;
import ch.zhaw.ase1.service.PersonService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("/jpa-config-hi.xml")
@ContextConfiguration(classes = { PersistenceJPAConfigXml.class }, loader = AnnotationConfigContextLoader.class)
public class BidServicePersistenceTest {


    @Autowired
    private BidService service;

    private Date january2021;

    @BeforeAll
    public void SetUp(){
        Calendar c = Calendar.getInstance();
        c.set(2021, 1, 2);
        january2021 = c.getTime();
    }

    // tests

    @Test
    public final void whenContextIsBootstrapped_thenNoExceptions() {
        //
    }

    @Test
    public final void whenEntityIsCreated_thenNoExceptions() {
        service.save(new BidEntity( 10, "", january2021));
    }

    @Test(expected = DataIntegrityViolationException.class)
    public final void whenInvalidEntityIsCreated_thenDataException() {
        service.save(new BidEntity( -1, "", january2021));
    }

    @Test
    public final void whenSameEntityIsCreatedTwice_noProblem() {
        final BidEntity entity = new BidEntity(10, "", january2021);
        service.save(entity);
        service.save(entity);
    }

    @Test
    public final void whenEntityIsCreated_thenFound() {
        final BidEntity entity = new BidEntity(10, "", january2021);
        service.save(entity);
        final BidEntity found = service.findOne(entity.getId());
        Assert.assertNotNull(found);
    }

}
