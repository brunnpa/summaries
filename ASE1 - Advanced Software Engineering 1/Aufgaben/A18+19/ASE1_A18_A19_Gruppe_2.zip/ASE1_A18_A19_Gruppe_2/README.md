# Gruppe 2 - Aufgabe 18/19

## Team:

- Pascal Brunner (brunnpa7)
- Maximilian König (koenimax)
- Martin Ponbauer (ponbamar)
- Aurel Schwitter (schwiaur)
- Lucca Willi (willilu1)

--- 
**Für die Prüfung der Funktionalität siehe Testklassen:**

- BeansXMLTest.java
- DependencyInjectionTest.java