package com.ase1.gruppe2.auktionsplatform;

import com.ase1.gruppe2.auktionsplatform.model.Auction;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource("classpath:beans.xml")
public class AuktionsplatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuktionsplatformApplication.class, args);
	}

}
