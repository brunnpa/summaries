package com.ase1.gruppe2.auktionsplatform.config;

import com.ase1.gruppe2.auktionsplatform.factory.AuctionFactory;
import com.ase1.gruppe2.auktionsplatform.model.Auction;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TestAuctionConfig {

    @Bean(name = "auctionCreatedWithoutXML")
    public Auction createTestAuction(){
        AuctionFactory factory = new AuctionFactory();
        return factory.createTestInstance();
    }
}
