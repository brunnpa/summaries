package com.ase1.gruppe2.auktionsplatform.factory;

import com.ase1.gruppe2.auktionsplatform.model.Auction;
import com.ase1.gruppe2.auktionsplatform.model.Category;

import java.time.LocalDateTime;

public class AuctionFactory {

    public Auction createTestInstance() {
        Category category = new Category("Computer & Hardware", "Alles rund um Computer und Hardware");

        LocalDateTime auctionStart = LocalDateTime.now().plusHours(2);
        LocalDateTime auctionEnd = LocalDateTime.now().plusDays(7);
        double startingPrice = 99.99;
        double fixedPrice = 999.00;
        return new Auction(auctionEnd,
                fixedPrice,
                20.00,
                auctionStart,
                startingPrice,
                "NOT_STARTED",
                "Nvidia RTX 3080",
                "Grafikkarte von Nvidia",
                "rtx3080.png", category,
                null);
    }
}
