package com.ase1.gruppe2.auktionsplatform.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Auction {

    private final LocalDateTime endDateTime;
    private final double fixedPrice;
    private final double minBidIncrement;
    private final LocalDateTime startDateTime;
    private final double startingPrice;
    private final String status;

    private final AuctionItem auctionItem;
    private final List<Bid> bids;
    private final Category category;
    private final List<PendingPayment> pendingPayments;
    private final UserAccount userAccount;


    public Auction(LocalDateTime endDateTime, double fixedPrice, double minBidIncrement, LocalDateTime startDateTime, double startingPrice, String status, String auctionItemTitle, String auctionItemDescription, String auctionItemPicture, Category category, UserAccount userAccount) {
        this.endDateTime = endDateTime;
        this.fixedPrice = fixedPrice;
        this.minBidIncrement = minBidIncrement;
        this.startDateTime = startDateTime;
        this.startingPrice = startingPrice;
        this.status = status;
        this.auctionItem = new AuctionItem(auctionItemDescription, auctionItemPicture, auctionItemTitle);
        this.bids = new ArrayList<>();
        this.category = category;
        this.pendingPayments = new ArrayList<>();
        this.userAccount = userAccount;
        this.addBid(startingPrice);
    }

    public Bid addBid(double bidAmount){
        Bid bid = new Bid(bidAmount, null, LocalDateTime.now());
        this.bids.add(bid);
        return bid;
    }

    public LocalDateTime getEndDateTime() {
        return endDateTime;
    }

    public double getFixedPrice() {
        return fixedPrice;
    }

    public double getMinBidIncrement() {
        return minBidIncrement;
    }

    public LocalDateTime getStartDateTime() {
        return startDateTime;
    }

    public double getStartingPrice() {
        return startingPrice;
    }

    public String getStatus() {
        return status;
    }

    public AuctionItem getAuctionItem() {
        return auctionItem;
    }

    public List<Bid> getBids() {
        return bids;
    }

    public Category getCategory() {
        return category;
    }

    public List<PendingPayment> getPendingPayments() {
        return pendingPayments;
    }

    public UserAccount getUserAccount() {
        return userAccount;
    }

    class Bid {
        private final double amount;
        private final String cancelExplanation;
        private final LocalDateTime placedAtDateTime;

        public Bid(double amount, String cancelExplanation, LocalDateTime placedAtDateTime) {
            this.amount = amount;
            this.cancelExplanation = cancelExplanation;
            this.placedAtDateTime = placedAtDateTime;
        }

        public double getAmount() {
            return amount;
        }

        public String getCancelExplanation() {
            return cancelExplanation;
        }

        public LocalDateTime getPlacedAtDateTime() {
            return placedAtDateTime;
        }
    }

    class AuctionItem {
        private String description;
        private String picture;
        private String title;

        public AuctionItem(String description, String picture, String title) {
            this.description = description;
            this.picture = picture;
            this.title = title;
        }

        public String getDescription() {
            return description;
        }

        public String getPicture() {
            return picture;
        }

        public String getTitle() {
            return title;
        }
    }
}
