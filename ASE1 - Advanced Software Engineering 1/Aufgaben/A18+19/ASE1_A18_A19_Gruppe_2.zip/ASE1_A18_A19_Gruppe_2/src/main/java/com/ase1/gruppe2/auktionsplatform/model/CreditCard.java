package com.ase1.gruppe2.auktionsplatform.model;

import java.time.LocalDate;
import java.util.List;

public class CreditCard extends PaymentInstrument{
    private final String cardNumber;
    private final String cardType;
    private final LocalDate expirationDate;
    private final String nameOnCard;

    public CreditCard(List<PaymentOrganization> paymentOrganizations, String cardNumber, String cardType, LocalDate expirationDate, String nameOnCard) {
        super(paymentOrganizations);
        this.cardNumber = cardNumber;
        this.cardType = cardType;
        this.expirationDate = expirationDate;
        this.nameOnCard = nameOnCard;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getCardType() {
        return cardType;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public String getNameOnCard() {
        return nameOnCard;
    }
}
