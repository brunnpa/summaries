package com.ase1.gruppe2.auktionsplatform.model;

import java.util.List;

public class OperatingCompany {
    private final PaymentOrganization paymentOrganization;
    private final List<UserAccount> userAccounts;

    public OperatingCompany(PaymentOrganization paymentOrganization, List<UserAccount> userAccounts) {
        this.paymentOrganization = paymentOrganization;
        this.userAccounts = userAccounts;
    }

    public PaymentOrganization getPaymentOrganization() {
        return paymentOrganization;
    }

    public List<UserAccount> getUserAccounts() {
        return userAccounts;
    }
}
