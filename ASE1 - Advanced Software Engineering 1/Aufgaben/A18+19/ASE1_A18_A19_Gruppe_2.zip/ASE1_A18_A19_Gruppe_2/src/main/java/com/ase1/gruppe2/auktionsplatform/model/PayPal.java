package com.ase1.gruppe2.auktionsplatform.model;

import java.util.List;

public class PayPal extends PaymentInstrument{
    private final String username;

    public PayPal(List<PaymentOrganization> paymentOrganizations, String username) {
        super(paymentOrganizations);
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}
