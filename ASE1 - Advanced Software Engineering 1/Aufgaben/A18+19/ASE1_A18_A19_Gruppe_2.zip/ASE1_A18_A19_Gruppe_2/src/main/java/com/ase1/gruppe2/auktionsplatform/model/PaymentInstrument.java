package com.ase1.gruppe2.auktionsplatform.model;

import java.util.List;

public abstract class  PaymentInstrument {
    protected final List<PaymentOrganization> paymentOrganizations;

    public PaymentInstrument(List<PaymentOrganization> paymentOrganizations) {
        this.paymentOrganizations = paymentOrganizations;
    }

    public List<PaymentOrganization> getPaymentOrganizations() {
        return paymentOrganizations;
    }
}
