package com.ase1.gruppe2.auktionsplatform.model;

import java.util.List;

public class PaymentOrganization {
    private final List<PaymentInstrument> paymentInstruments;
    private final List<OperatingCompany> operatingCompanies;

    public PaymentOrganization(List<PaymentInstrument> paymentInstruments, List<OperatingCompany> operatingCompanies) {
        this.paymentInstruments = paymentInstruments;
        this.operatingCompanies = operatingCompanies;
    }

    public List<PaymentInstrument> getPaymentInstruments() {
        return paymentInstruments;
    }

    public List<OperatingCompany> getOperatingCompanies() {
        return operatingCompanies;
    }
}
