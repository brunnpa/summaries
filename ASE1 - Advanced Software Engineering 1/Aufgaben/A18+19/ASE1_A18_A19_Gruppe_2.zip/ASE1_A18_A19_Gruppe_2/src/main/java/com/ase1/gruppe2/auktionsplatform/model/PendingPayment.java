package com.ase1.gruppe2.auktionsplatform.model;

public class PendingPayment {
    private final double amount;
    private final Auction auction;

    public PendingPayment(double amount, Auction auction) {
        this.amount = amount;
        this.auction = auction;
    }

    public double getAmount() {
        return amount;
    }

    public Auction getAuction() {
        return auction;
    }
}
