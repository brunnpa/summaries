package com.ase1.gruppe2.auktionsplatform.model;

import java.util.List;

public class UserAccount {

    private final String email;
    private final String firstName;
    private final String lastName;
    private final boolean locked;
    private final String password;
    private final int thresholdOpenPayments;
    private final String username;

    private final List<PendingPayment> pendingPayments;
    private final List<PaymentInstrument> paymentInstruments;
    private final List<Auction> auctions;
    private final List<Auction.Bid> bids;

    public UserAccount(String email, String firstName, String lastName, boolean locked, String password, int thresholdOpenPayments, String username, List<PendingPayment> pendingPayments, List<PaymentInstrument> paymentInstruments, List<Auction> auctions, List<Auction.Bid> bids) {
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.locked = locked;
        this.password = password;
        this.thresholdOpenPayments = thresholdOpenPayments;
        this.username = username;
        this.pendingPayments = pendingPayments;
        this.paymentInstruments = paymentInstruments;
        this.auctions = auctions;
        this.bids = bids;
    }

    public String getEmail() {
        return email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public boolean isLocked() {
        return locked;
    }

    public String getPassword() {
        return password;
    }

    public int getThresholdOpenPayments() {
        return thresholdOpenPayments;
    }

    public String getUsername() {
        return username;
    }

    public List<PendingPayment> getPendingPayments() {
        return pendingPayments;
    }

    public List<PaymentInstrument> getPaymentInstruments() {
        return paymentInstruments;
    }

    public List<Auction> getAuctions() {
        return auctions;
    }

    public List<Auction.Bid> getBids() {
        return bids;
    }
}
