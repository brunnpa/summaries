package com.ase1.gruppe2.auktionsplatform;

import com.ase1.gruppe2.auktionsplatform.model.Auction;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.BeansException;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

@SpringBootTest
class BeansXMLTest implements ApplicationContextAware {

	private ApplicationContext context;

	@Test
	void contextLoads() {
		Auction auction = (Auction) context.getBean("testAuction");
		Assertions.assertNotNull(auction);
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.context = applicationContext;
	}
}
