package com.ase1.gruppe2.auktionsplatform;

import com.ase1.gruppe2.auktionsplatform.model.Auction;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependencyInjectionTest {

    @Qualifier("auctionCreatedWithoutXML")
    @Autowired
    private Auction auction;

    @Test
    void testDependencyInjectionOfAuction(){
        Assertions.assertNotNull(auction);
    }
}
