% L�st das Anfangswertproblem mit dem klassischen Runge-Kutta Verfahren
%
% PARAMETER
% f = die Funktion
% a,b = Intervall
% n = Anzahl Berechnungsschritte
% y0 = Anfangswert f�r f(a)
%
% RETURN
% x = xi Werte
% y = yi Werte
%
% SAMPLE
% [x,y] = HELPER_S6_RUNGE_KUTTA(@(x,y)x.^2 + 0.1 * y,-1.5,1.5,5,0)
function [x,y] = HELPER_S6_RUNGE_KUTTA(f,a,b,n,y0)
    % h berechnen
    h = (b - a) / n;
    
    % Vektoren x und y initialisieren
    x = a:h:b;
    lenX = length(x);
    y = zeros(1, lenX);
    y(1) = y0;
    
    for i=1:lenX-1
        k1 = f(x(i), y(i));
        k2 = f((x(i)+h/2),(y(i)+(h/2)*k1));
        k3 = f((x(i)+h/2),(y(i)+(h/2)*k2));
        k4 = f((x(i)+h),(y(i)+h*k3));
        x(i+1) = x(i)+h;
        y(i+1) = y(i) + h * (1/6) * (k1 + 2*k2 + 2*k3 + k4);
    end
end

