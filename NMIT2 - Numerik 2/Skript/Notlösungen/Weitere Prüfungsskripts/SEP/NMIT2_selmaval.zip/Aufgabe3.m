% NMIT2 SEP - Aufgabe 3
% Valmir Selmani