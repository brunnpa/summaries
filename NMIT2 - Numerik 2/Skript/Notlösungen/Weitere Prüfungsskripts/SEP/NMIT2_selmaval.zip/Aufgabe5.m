% NMIT2 SEP - Aufgabe 5
% Valmir Selmani