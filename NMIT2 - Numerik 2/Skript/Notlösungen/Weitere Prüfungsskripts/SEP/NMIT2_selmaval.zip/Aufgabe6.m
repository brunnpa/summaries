% NMIT2 SEP - Aufgabe 6
% Valmir Selmani

% Teilaufgabe a


% Teilaufgabe b


% Teilaufgabe c