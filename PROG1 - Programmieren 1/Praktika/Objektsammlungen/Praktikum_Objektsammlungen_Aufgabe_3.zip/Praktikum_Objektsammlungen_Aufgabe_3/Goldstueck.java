import java.awt.Point;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;    

/**
 * Beschreiben Sie hier die Klasse Goldstueck.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Goldstueck
{
    private Point punkt;
    private int wert;
    
    /**
     * Konstruktor für Objekte der Klasse Goldstueck
     */
    public Goldstueck(Point punkt)
    {
        wert = (int)(Math.random()*5+1);
        this.punkt = punkt;
    }
    
    public Goldstueck()
    {
                wert = (int)(Math.random()*5+1);
    }

    public Point getPunkt()
    {
        return punkt;
    }
    
    public int getWert()
    {
        return wert;
    }
}
