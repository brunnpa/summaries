# 04_Praktikum-1_Snake
Code project used in the context of the PROG1 course.
