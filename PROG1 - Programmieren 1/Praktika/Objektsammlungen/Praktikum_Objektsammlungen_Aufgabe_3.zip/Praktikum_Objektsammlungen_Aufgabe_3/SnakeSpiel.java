import java.awt.Point;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * Spielklasse des Spiels Snake.
 *
 * Ziel dieses Spiels ist es alle Goldstuecke einzusammeln und 
 * die Tuer zu erreichen, ohne sich selber zu beissen oder in 
 * die Spielfeldbegrenzung reinzukriechen. 
 */
public class SnakeSpiel {
    private Schlange schlange;
    private Tuer tuer;
    private Spielfeld spielfeld;
    private Point goldStueck;
    private ArrayList<Goldstueck> goldStuecke;
    private boolean spielLaeuft = true;
    private int anzahlGoldstuecke;

    /**
     * Konstruktor ohne Parameter, der Wert von anzahlGoldstuecke wird auf den Defaultwert von 10 gesetzt
     */
    public SnakeSpiel()
    {
        goldStuecke = new ArrayList<Goldstueck>();
        anzahlGoldstuecke = 10;
    }
    
    /**
     * Konstruktor mit Parameter
     * @param anzahlGoldstuecke gibt an wie viele Goldstuecke auf dem Spielfeld gezeichnet werden sollen
     */
    public SnakeSpiel(int anzahlGoldstuecke)
    {
        goldStuecke = new ArrayList<Goldstueck>();
        this.anzahlGoldstuecke = anzahlGoldstuecke;
    }
    
    /**
     * Startet das Spiel.
     */
    public void spielen(int anzahlGoldstuecke) {
        spielInitialisieren(anzahlGoldstuecke);
        
        while (spielLaeuft) {
            ueberpruefeSpielstatus();
            zeichneSpielfeld();
            fuehreSpielzugAus();
        }   
    }

    public static void main(String[] args) {
        new SnakeSpiel().spielen(Integer.parseInt(args[0]));
    }

    private void spielInitialisieren(int anzahlGoldstuecke) {
        tuer = new Tuer(0, 5);
        spielfeld = new Spielfeld(40, 10);
        schlange = new Schlange(30, 2);
        
        goldStuecke = goldstueckeErstellen(anzahlGoldstuecke);
    }

    private ArrayList<Goldstueck> goldstueckeErstellen(int anzahlGoldstuecke)
    {                 
        ArrayList<Goldstueck> goldStuecke = new ArrayList<Goldstueck>(); 
        int counter = 0;
        while(counter < anzahlGoldstuecke) //Versuch mit anderer Variablen
        {
            goldStuecke.add(spielfeld.erzeugeZufallspunktInnerhalb());
            counter++;
        }
        
        // for (int counter = 0; counter <= anzahlGoldstuecke; counter++)
        // {
            // Point punkt = spielfeld.erzeugeZufallspunktInnerhalb();
            // goldStuecke.add(new Goldstueck(punkt));
        // }
        return goldStuecke;
    }

    public void setAnzahlGoldstuecke(int anzahl)
    {
        anzahlGoldstuecke = anzahl;
    }

        private void zeichneSpielfeld() {
        char ausgabeZeichen;
        for (int y = 0; y < spielfeld.gibHoehe(); y++) {
            for (int x = 0; x < spielfeld.gibBreite(); x++) {
                Point punkt = new Point(x, y);
                ausgabeZeichen = '.';
                if (schlange.istAufPunkt(punkt)) {
                    ausgabeZeichen = '@';
                } else if (istEinGoldstueckAufPunkt(punkt)) {
                    ausgabeZeichen = '$';
                } else if (tuer.istAufPunkt(punkt)) {
                    ausgabeZeichen = '#';
                } 
                if(schlange.istKopfAufPunkt(punkt)) {
                    ausgabeZeichen = 'S';         
                }
                System.out.print(ausgabeZeichen);
            }
            System.out.println();
        }
    }

    private boolean istEinGoldstueckAufPunkt(Point punkt) {
        return goldStuecke != null && goldStuecke.equals(punkt);
    }

    private void ueberpruefeSpielstatus() {
        if (istEinGoldstueckAufPunkt(schlange.gibPosition())) {
            goldStuecke = null;
            //schlange.wachsen();
            System.out.println("Goldstueck eingesammelt.");
        }
        if (istVerloren()){
            System.out.println("Verloren!");
            spielLaeuft = false;
        }
        if (istGewonnen()){
            System.out.println("Gewonnen!");
            spielLaeuft = false;
        }
    }

    private boolean istGewonnen() {
        return goldStuecke == null && 
        tuer.istAufPunkt(schlange.gibPosition());
    }

    private boolean istVerloren() {
        return schlange.istKopfAufKoerper() || 
        !spielfeld.istPunktInSpielfeld(schlange.gibPosition());
    }

    private void fuehreSpielzugAus() {
        char eingabe = liesZeichenVonTastatur();
        schlange.bewege(eingabe);
    }

    private char liesZeichenVonTastatur() {
        Scanner scanner = new Scanner(System.in);
        char konsolenEingabe = scanner.next().charAt(0);
        return konsolenEingabe;
    }
}