/**
 * Domain logic of project Forum
 * @author feit
 *
 */
package ch.zhaw.swen1.forum.domain;