var task = {
  title : "Default-Tasktitle",
  done : false,
}

var Task = function(title) {
  this.title = title
}

Task.prototype = task
